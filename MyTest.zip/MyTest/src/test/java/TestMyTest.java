
import com.ko.MyTest;
import org.junit.Test;

public class TestMyTest {

    @Test
    public void testCountStudent(){
        MyTest myTest = new MyTest();
        myTest.countStudent();
    }

    @Test
    public void testCountStudent2(){
        MyTest myTest = new MyTest();
        myTest.countStudentStageTwo();
    }

}
