package com.ko;

public class MyTest {
    public void countStudent(){
        String threeV = "Fizz";
        String fiveV = "Buzz";
        StringBuffer sbf = new StringBuffer();
        for(int i=1; i<=100; i++){
            if(i%3==0) sbf.append(threeV);
            if(i%5==0) sbf.append(fiveV);
            if(sbf.toString().length() == 0){
                System.out.println(i);
            }else {
                System.out.println(sbf.toString());
            }
            sbf.setLength(0);
            sbf.trimToSize();
        }
    }

    public void countStudentStageTwo(){
        String threeV = "Fizz";
        String fiveV = "Buzz";
        StringBuffer sbf = new StringBuffer();
        for(int i=1; i<=100; i++){
            if(i%3==0 || (String.valueOf(i)).indexOf("3")>0) sbf.append(threeV);
            if(i%5==0 || (String.valueOf(i)).indexOf("5")>0) sbf.append(fiveV);
            if(sbf.toString().length() == 0){
                System.out.println(i);
            }else {
                System.out.println(sbf.toString());
            }
            sbf.setLength(0);
            sbf.trimToSize();
        }
    }
}

